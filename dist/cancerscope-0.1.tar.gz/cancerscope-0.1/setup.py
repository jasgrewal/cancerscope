from setuptools import setup

setup(name='cancerscope', version='0.1', description='Pan-cancer classifier using RNA-Seq', url='http://github.com/jasgrewal/cancerscope/', author='Jasleen Grewal', author_email='grewalj23@gmail.com', license='MIT', packages=['cancerscope'], zip_safe=False)

